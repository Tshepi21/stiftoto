﻿namespace Tshepiso_Mohatlane__Project_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnregisterform1 = new System.Windows.Forms.Button();
            this.Btnsigninform1 = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnexitform1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.ForeColor = System.Drawing.Color.Gold;
            this.label1.Name = "label1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // btnregisterform1
            // 
            this.btnregisterform1.BackColor = System.Drawing.Color.Gold;
            resources.ApplyResources(this.btnregisterform1, "btnregisterform1");
            this.btnregisterform1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnregisterform1.Name = "btnregisterform1";
            this.btnregisterform1.UseVisualStyleBackColor = false;
            this.btnregisterform1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Btnsigninform1
            // 
            this.Btnsigninform1.BackColor = System.Drawing.Color.Gold;
            resources.ApplyResources(this.Btnsigninform1, "Btnsigninform1");
            this.Btnsigninform1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Btnsigninform1.Name = "Btnsigninform1";
            this.Btnsigninform1.UseVisualStyleBackColor = false;
            this.Btnsigninform1.Click += new System.EventHandler(this.button2_Click);
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.BackColor = System.Drawing.Color.Gold;
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Name = "label2";
            // 
            // btnexitform1
            // 
            this.btnexitform1.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.btnexitform1, "btnexitform1");
            this.btnexitform1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnexitform1.Name = "btnexitform1";
            this.btnexitform1.UseVisualStyleBackColor = false;
            this.btnexitform1.Click += new System.EventHandler(this.button3_Click);
            // 
            // Form1
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.Controls.Add(this.btnexitform1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.Btnsigninform1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnregisterform1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Name = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnregisterform1;
        private System.Windows.Forms.Button Btnsigninform1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnexitform1;
    }
}

