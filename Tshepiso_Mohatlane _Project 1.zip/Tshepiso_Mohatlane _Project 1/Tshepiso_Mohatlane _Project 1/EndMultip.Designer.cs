﻿namespace Tshepiso_Mohatlane__Project_1
{
    partial class EndMultip
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EndMultip));
            this.brnpalyagin = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnlplayer1 = new System.Windows.Forms.Panel();
            this.lblname = new System.Windows.Forms.Label();
            this.pbwin = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblscore = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pnlwinner = new System.Windows.Forms.Panel();
            this.lblwinname = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pnlplayer2 = new System.Windows.Forms.Panel();
            this.lblname2 = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblscore2 = new System.Windows.Forms.Label();
            this.btnwinner = new System.Windows.Forms.Button();
            this.lblwinner2 = new System.Windows.Forms.Label();
            this.pnlplayer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlwinner.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.pnlplayer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            this.SuspendLayout();
            // 
            // brnpalyagin
            // 
            this.brnpalyagin.BackColor = System.Drawing.Color.Red;
            this.brnpalyagin.Font = new System.Drawing.Font("Ravie", 9.75F, System.Drawing.FontStyle.Bold);
            this.brnpalyagin.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.brnpalyagin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.brnpalyagin.Location = new System.Drawing.Point(553, 311);
            this.brnpalyagin.Name = "brnpalyagin";
            this.brnpalyagin.Size = new System.Drawing.Size(246, 64);
            this.brnpalyagin.TabIndex = 15;
            this.brnpalyagin.Text = "PLAY AGAIN";
            this.brnpalyagin.UseVisualStyleBackColor = false;
            this.brnpalyagin.Click += new System.EventHandler(this.brnpalyagin_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Red;
            this.btnexit.Font = new System.Drawing.Font("Ravie", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnexit.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnexit.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnexit.Location = new System.Drawing.Point(31, 311);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(241, 64);
            this.btnexit.TabIndex = 14;
            this.btnexit.Text = "EXIT";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gold;
            this.label1.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.Highlight;
            this.label1.Location = new System.Drawing.Point(337, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(126, 26);
            this.label1.TabIndex = 13;
            this.label1.Text = "THE END ";
            // 
            // pnlplayer1
            // 
            this.pnlplayer1.BackColor = System.Drawing.Color.Gold;
            this.pnlplayer1.Controls.Add(this.lblname);
            this.pnlplayer1.Controls.Add(this.pbwin);
            this.pnlplayer1.Controls.Add(this.label3);
            this.pnlplayer1.Controls.Add(this.label2);
            this.pnlplayer1.Controls.Add(this.lblscore);
            this.pnlplayer1.Location = new System.Drawing.Point(12, 52);
            this.pnlplayer1.Name = "pnlplayer1";
            this.pnlplayer1.Size = new System.Drawing.Size(260, 253);
            this.pnlplayer1.TabIndex = 12;
            this.pnlplayer1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblname.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.Red;
            this.lblname.Location = new System.Drawing.Point(29, 26);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(171, 26);
            this.lblname.TabIndex = 6;
            this.lblname.Text = "YOUR SCORE";
            // 
            // pbwin
            // 
            this.pbwin.Image = ((System.Drawing.Image)(resources.GetObject("pbwin.Image")));
            this.pbwin.Location = new System.Drawing.Point(3, 135);
            this.pbwin.Name = "pbwin";
            this.pbwin.Size = new System.Drawing.Size(254, 115);
            this.pbwin.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbwin.TabIndex = 4;
            this.pbwin.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Ravie", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(47, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 39);
            this.label3.TabIndex = 3;
            this.label3.Text = "20";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(29, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(171, 26);
            this.label2.TabIndex = 0;
            this.label2.Text = "YOUR SCORE";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblscore
            // 
            this.lblscore.AutoSize = true;
            this.lblscore.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblscore.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscore.ForeColor = System.Drawing.Color.Gold;
            this.lblscore.Location = new System.Drawing.Point(47, 47);
            this.lblscore.Name = "lblscore";
            this.lblscore.Size = new System.Drawing.Size(109, 39);
            this.lblscore.TabIndex = 1;
            this.lblscore.Text = "label3";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(-1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(803, 468);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pnlwinner
            // 
            this.pnlwinner.BackColor = System.Drawing.Color.Gold;
            this.pnlwinner.Controls.Add(this.lblwinner2);
            this.pnlwinner.Controls.Add(this.lblwinname);
            this.pnlwinner.Controls.Add(this.label5);
            this.pnlwinner.Controls.Add(this.label4);
            this.pnlwinner.Controls.Add(this.pictureBox3);
            this.pnlwinner.Location = new System.Drawing.Point(278, 52);
            this.pnlwinner.Name = "pnlwinner";
            this.pnlwinner.Size = new System.Drawing.Size(255, 333);
            this.pnlwinner.TabIndex = 13;
            // 
            // lblwinname
            // 
            this.lblwinname.AutoSize = true;
            this.lblwinname.Font = new System.Drawing.Font("Ravie", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwinname.ForeColor = System.Drawing.Color.Red;
            this.lblwinname.Location = new System.Drawing.Point(10, 94);
            this.lblwinname.Name = "lblwinname";
            this.lblwinname.Size = new System.Drawing.Size(239, 36);
            this.lblwinname.TabIndex = 8;
            this.lblwinname.Text = "YOUR SCORE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label5.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Red;
            this.label5.Location = new System.Drawing.Point(0, 60);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(249, 26);
            this.label5.TabIndex = 7;
            this.label5.Text = "CONGRATULATIONS";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label4.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(24, 12);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(214, 26);
            this.label4.TabIndex = 6;
            this.label4.Text = "THE WINNER IS ";
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(0, 174);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(255, 149);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // pnlplayer2
            // 
            this.pnlplayer2.BackColor = System.Drawing.Color.Gold;
            this.pnlplayer2.Controls.Add(this.lblname2);
            this.pnlplayer2.Controls.Add(this.pictureBox5);
            this.pnlplayer2.Controls.Add(this.label9);
            this.pnlplayer2.Controls.Add(this.label10);
            this.pnlplayer2.Controls.Add(this.lblscore2);
            this.pnlplayer2.Location = new System.Drawing.Point(547, 52);
            this.pnlplayer2.Name = "pnlplayer2";
            this.pnlplayer2.Size = new System.Drawing.Size(255, 253);
            this.pnlplayer2.TabIndex = 14;
            // 
            // lblname2
            // 
            this.lblname2.AutoSize = true;
            this.lblname2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblname2.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname2.ForeColor = System.Drawing.Color.Red;
            this.lblname2.Location = new System.Drawing.Point(39, 26);
            this.lblname2.Name = "lblname2";
            this.lblname2.Size = new System.Drawing.Size(171, 26);
            this.lblname2.TabIndex = 6;
            this.lblname2.Text = "YOUR SCORE";
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(3, 133);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(249, 117);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Ravie", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Red;
            this.label9.Location = new System.Drawing.Point(64, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 39);
            this.label9.TabIndex = 3;
            this.label9.Text = "20";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Ravie", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(39, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(171, 26);
            this.label10.TabIndex = 0;
            this.label10.Text = "YOUR SCORE";
            // 
            // lblscore2
            // 
            this.lblscore2.AutoSize = true;
            this.lblscore2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblscore2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblscore2.ForeColor = System.Drawing.Color.Gold;
            this.lblscore2.Location = new System.Drawing.Point(64, 52);
            this.lblscore2.Name = "lblscore2";
            this.lblscore2.Size = new System.Drawing.Size(158, 39);
            this.lblscore2.TabIndex = 1;
            this.lblscore2.Text = "lblname2";
            // 
            // btnwinner
            // 
            this.btnwinner.BackColor = System.Drawing.Color.Red;
            this.btnwinner.Font = new System.Drawing.Font("Ravie", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnwinner.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnwinner.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnwinner.Location = new System.Drawing.Point(292, 391);
            this.btnwinner.Name = "btnwinner";
            this.btnwinner.Size = new System.Drawing.Size(241, 64);
            this.btnwinner.TabIndex = 18;
            this.btnwinner.Text = "See the winner";
            this.btnwinner.UseVisualStyleBackColor = false;
            this.btnwinner.Click += new System.EventHandler(this.btnwinner_Click);
            // 
            // lblwinner2
            // 
            this.lblwinner2.AutoSize = true;
            this.lblwinner2.Font = new System.Drawing.Font("Ravie", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwinner2.ForeColor = System.Drawing.Color.Red;
            this.lblwinner2.Location = new System.Drawing.Point(13, 135);
            this.lblwinner2.Name = "lblwinner2";
            this.lblwinner2.Size = new System.Drawing.Size(239, 36);
            this.lblwinner2.TabIndex = 9;
            this.lblwinner2.Text = "YOUR SCORE";
            // 
            // EndMultip
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 467);
            this.Controls.Add(this.btnwinner);
            this.Controls.Add(this.pnlplayer2);
            this.Controls.Add(this.pnlwinner);
            this.Controls.Add(this.brnpalyagin);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pnlplayer1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "EndMultip";
            this.Text = "EndMultip";
            this.Load += new System.EventHandler(this.EndMultip_Load);
            this.pnlplayer1.ResumeLayout(false);
            this.pnlplayer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlwinner.ResumeLayout(false);
            this.pnlwinner.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.pnlplayer2.ResumeLayout(false);
            this.pnlplayer2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button brnpalyagin;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlplayer1;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.PictureBox pbwin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblscore;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel pnlwinner;
        private System.Windows.Forms.Label lblwinname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel pnlplayer2;
        private System.Windows.Forms.Label lblname2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblscore2;
        private System.Windows.Forms.Button btnwinner;
        private System.Windows.Forms.Label lblwinner2;
    }
}