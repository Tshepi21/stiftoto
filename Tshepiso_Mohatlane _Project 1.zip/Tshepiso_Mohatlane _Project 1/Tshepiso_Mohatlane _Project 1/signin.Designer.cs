﻿namespace Tshepiso_Mohatlane__Project_1
{
    partial class signin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(signin));
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnback = new System.Windows.Forms.Button();
            this.btnsigin = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.txtpasswordsignin = new System.Windows.Forms.TextBox();
            this.txtusernamesignin = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Ravie", 12F, System.Drawing.FontStyle.Underline);
            this.label6.ForeColor = System.Drawing.Color.Gold;
            this.label6.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label6.Location = new System.Drawing.Point(24, 15);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(257, 22);
            this.label6.TabIndex = 14;
            this.label6.Text = "WELCOME TO STIFTOTO";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pictureBox1.Location = new System.Drawing.Point(22, 38);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 73);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // btnback
            // 
            this.btnback.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnback.Font = new System.Drawing.Font("Ravie", 9.75F);
            this.btnback.ForeColor = System.Drawing.Color.Gold;
            this.btnback.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnback.Location = new System.Drawing.Point(165, 243);
            this.btnback.Name = "btnback";
            this.btnback.Size = new System.Drawing.Size(100, 31);
            this.btnback.TabIndex = 12;
            this.btnback.Text = "back";
            this.btnback.UseVisualStyleBackColor = false;
            this.btnback.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnsigin
            // 
            this.btnsigin.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnsigin.Font = new System.Drawing.Font("Ravie", 9.75F);
            this.btnsigin.ForeColor = System.Drawing.Color.Gold;
            this.btnsigin.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.btnsigin.Location = new System.Drawing.Point(22, 243);
            this.btnsigin.Name = "btnsigin";
            this.btnsigin.Size = new System.Drawing.Size(114, 31);
            this.btnsigin.TabIndex = 11;
            this.btnsigin.Text = "sigin";
            this.btnsigin.UseVisualStyleBackColor = false;
            this.btnsigin.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtpasswordsignin);
            this.panel1.Controls.Add(this.txtusernamesignin);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(22, 104);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(253, 133);
            this.panel1.TabIndex = 10;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Ravie", 8.25F);
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label4.Location = new System.Drawing.Point(41, 101);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 17);
            this.label4.TabIndex = 6;
            this.label4.Text = "HOPE YOU READY!!!!!!";
            // 
            // txtpasswordsignin
            // 
            this.txtpasswordsignin.Location = new System.Drawing.Point(112, 64);
            this.txtpasswordsignin.Name = "txtpasswordsignin";
            this.txtpasswordsignin.PasswordChar = '*';
            this.txtpasswordsignin.Size = new System.Drawing.Size(131, 20);
            this.txtpasswordsignin.TabIndex = 5;
            // 
            // txtusernamesignin
            // 
            this.txtusernamesignin.Location = new System.Drawing.Point(112, 23);
            this.txtusernamesignin.Name = "txtusernamesignin";
            this.txtusernamesignin.Size = new System.Drawing.Size(131, 20);
            this.txtusernamesignin.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Ravie", 8.25F);
            this.label2.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label2.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label2.Location = new System.Drawing.Point(3, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "USERNAME";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Ravie", 8.25F);
            this.label3.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label3.Location = new System.Drawing.Point(3, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "PASSWORD";
            // 
            // signin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.ClientSize = new System.Drawing.Size(303, 289);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btnback);
            this.Controls.Add(this.btnsigin);
            this.Controls.Add(this.panel1);
            this.Name = "signin";
            this.Text = "signin";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnback;
        private System.Windows.Forms.Button btnsigin;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtpasswordsignin;
        private System.Windows.Forms.TextBox txtusernamesignin;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}