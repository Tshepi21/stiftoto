﻿namespace Tshepiso_Mohatlane__Project_1
{
    partial class player22
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(player22));
            this.lblplayer2name = new System.Windows.Forms.Label();
            this.lblname1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.btnfinish = new System.Windows.Forms.Button();
            this.btnstart = new System.Windows.Forms.Button();
            this.pnlealine = new System.Windows.Forms.Panel();
            this.lblscore4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblincorrect3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pbcross = new System.Windows.Forms.PictureBox();
            this.lblcorrect3 = new System.Windows.Forms.Label();
            this.pbtick = new System.Windows.Forms.PictureBox();
            this.btnhip = new System.Windows.Forms.Button();
            this.lblanswer3 = new System.Windows.Forms.Label();
            this.btnrnb = new System.Windows.Forms.Button();
            this.btnhouse = new System.Windows.Forms.Button();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pnlbaby = new System.Windows.Forms.Panel();
            this.lblscore3 = new System.Windows.Forms.Label();
            this.lblwrong2 = new System.Windows.Forms.Label();
            this.pbwrong2 = new System.Windows.Forms.PictureBox();
            this.pbrightt2 = new System.Windows.Forms.PictureBox();
            this.lblincorrbaby = new System.Windows.Forms.Label();
            this.lblcorrbabby = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnfuture = new System.Windows.Forms.Button();
            this.btndrake = new System.Windows.Forms.Button();
            this.btnjustin = new System.Windows.Forms.Button();
            this.pnlcarly = new System.Windows.Forms.Panel();
            this.lblscore2 = new System.Windows.Forms.Label();
            this.lblanswers1 = new System.Windows.Forms.Label();
            this.pbwrong1 = new System.Windows.Forms.PictureBox();
            this.pbright = new System.Windows.Forms.PictureBox();
            this.lblincorrcarly = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblcorrectcarly = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.btntaylor = new System.Windows.Forms.Button();
            this.btnladygag = new System.Windows.Forms.Button();
            this.btncarly = new System.Windows.Forms.Button();
            this.pnldrake = new System.Windows.Forms.Panel();
            this.lblscore1 = new System.Windows.Forms.Label();
            this.pbwrong = new System.Windows.Forms.PictureBox();
            this.Lblanswer = new System.Windows.Forms.Label();
            this.pbcorrect = new System.Windows.Forms.PictureBox();
            this.lblincorrectdrake = new System.Windows.Forms.Label();
            this.lblcorrectdrake = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.btnelectrodrake = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btntrapdrake = new System.Windows.Forms.Button();
            this.btnhipop = new System.Windows.Forms.Button();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Lblscoreplayer1 = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.pnlealine.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbcross)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbtick)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.pnlbaby.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwrong2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrightt2)).BeginInit();
            this.pnlcarly.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwrong1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbright)).BeginInit();
            this.pnldrake.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwrong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcorrect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // lblplayer2name
            // 
            this.lblplayer2name.AutoSize = true;
            this.lblplayer2name.BackColor = System.Drawing.Color.Gold;
            this.lblplayer2name.Font = new System.Drawing.Font("Ravie", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblplayer2name.ForeColor = System.Drawing.Color.Red;
            this.lblplayer2name.Location = new System.Drawing.Point(332, 57);
            this.lblplayer2name.Name = "lblplayer2name";
            this.lblplayer2name.Size = new System.Drawing.Size(371, 36);
            this.lblplayer2name.TabIndex = 51;
            this.lblplayer2name.Text = "LAST FRIDAY NIGHT";
            // 
            // lblname1
            // 
            this.lblname1.AutoSize = true;
            this.lblname1.BackColor = System.Drawing.Color.Gold;
            this.lblname1.Font = new System.Drawing.Font("Ravie", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname1.ForeColor = System.Drawing.Color.Red;
            this.lblname1.Location = new System.Drawing.Point(685, 409);
            this.lblname1.Name = "lblname1";
            this.lblname1.Size = new System.Drawing.Size(180, 19);
            this.lblname1.TabIndex = 50;
            this.lblname1.Text = "LAST FRIDAY NIGHT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Gold;
            this.label4.Font = new System.Drawing.Font("Ravie", 21.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(185, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(664, 39);
            this.label4.TabIndex = 42;
            this.label4.Text = "WELCOME IT IS PLAYER1 CHANCE ";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(746, 438);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(0, 13);
            this.lblname.TabIndex = 49;
            // 
            // btnfinish
            // 
            this.btnfinish.BackColor = System.Drawing.Color.Red;
            this.btnfinish.Font = new System.Drawing.Font("Ravie", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfinish.Location = new System.Drawing.Point(430, 392);
            this.btnfinish.Name = "btnfinish";
            this.btnfinish.Size = new System.Drawing.Size(209, 86);
            this.btnfinish.TabIndex = 48;
            this.btnfinish.Text = "FINISH";
            this.btnfinish.UseVisualStyleBackColor = false;
            this.btnfinish.Click += new System.EventHandler(this.btnfinish_Click);
            // 
            // btnstart
            // 
            this.btnstart.BackColor = System.Drawing.Color.Gold;
            this.btnstart.Font = new System.Drawing.Font("Ravie", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnstart.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btnstart.Location = new System.Drawing.Point(172, 393);
            this.btnstart.Name = "btnstart";
            this.btnstart.Size = new System.Drawing.Size(199, 86);
            this.btnstart.TabIndex = 47;
            this.btnstart.Text = "START";
            this.btnstart.UseVisualStyleBackColor = false;
            this.btnstart.Click += new System.EventHandler(this.btnstart_Click);
            // 
            // pnlealine
            // 
            this.pnlealine.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.pnlealine.Controls.Add(this.lblscore4);
            this.pnlealine.Controls.Add(this.label2);
            this.pnlealine.Controls.Add(this.lblincorrect3);
            this.pnlealine.Controls.Add(this.label1);
            this.pnlealine.Controls.Add(this.pbcross);
            this.pnlealine.Controls.Add(this.lblcorrect3);
            this.pnlealine.Controls.Add(this.pbtick);
            this.pnlealine.Controls.Add(this.btnhip);
            this.pnlealine.Controls.Add(this.lblanswer3);
            this.pnlealine.Controls.Add(this.btnrnb);
            this.pnlealine.Controls.Add(this.btnhouse);
            this.pnlealine.Controls.Add(this.pictureBox6);
            this.pnlealine.Location = new System.Drawing.Point(679, 99);
            this.pnlealine.Name = "pnlealine";
            this.pnlealine.Size = new System.Drawing.Size(209, 282);
            this.pnlealine.TabIndex = 46;
            this.pnlealine.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlealine_Paint);
            // 
            // lblscore4
            // 
            this.lblscore4.AutoSize = true;
            this.lblscore4.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblscore4.Location = new System.Drawing.Point(145, 255);
            this.lblscore4.Name = "lblscore4";
            this.lblscore4.Size = new System.Drawing.Size(33, 13);
            this.lblscore4.TabIndex = 31;
            this.lblscore4.Text = "TIME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Gold;
            this.label2.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(34, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 17);
            this.label2.TabIndex = 28;
            this.label2.Text = "WHICH GENRE";
            // 
            // lblincorrect3
            // 
            this.lblincorrect3.BackColor = System.Drawing.Color.Red;
            this.lblincorrect3.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblincorrect3.Location = new System.Drawing.Point(45, 122);
            this.lblincorrect3.Name = "lblincorrect3";
            this.lblincorrect3.Size = new System.Drawing.Size(97, 20);
            this.lblincorrect3.TabIndex = 31;
            this.lblincorrect3.Text = "label16";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Gold;
            this.label1.Location = new System.Drawing.Point(164, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "TIME";
            // 
            // pbcross
            // 
            this.pbcross.Image = ((System.Drawing.Image)(resources.GetObject("pbcross.Image")));
            this.pbcross.Location = new System.Drawing.Point(42, 138);
            this.pbcross.Name = "pbcross";
            this.pbcross.Size = new System.Drawing.Size(100, 72);
            this.pbcross.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbcross.TabIndex = 29;
            this.pbcross.TabStop = false;
            // 
            // lblcorrect3
            // 
            this.lblcorrect3.BackColor = System.Drawing.Color.Lime;
            this.lblcorrect3.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcorrect3.Location = new System.Drawing.Point(58, 136);
            this.lblcorrect3.Name = "lblcorrect3";
            this.lblcorrect3.Size = new System.Drawing.Size(84, 20);
            this.lblcorrect3.TabIndex = 30;
            this.lblcorrect3.Text = "label13";
            // 
            // pbtick
            // 
            this.pbtick.Image = ((System.Drawing.Image)(resources.GetObject("pbtick.Image")));
            this.pbtick.Location = new System.Drawing.Point(61, 150);
            this.pbtick.Name = "pbtick";
            this.pbtick.Size = new System.Drawing.Size(74, 76);
            this.pbtick.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbtick.TabIndex = 29;
            this.pbtick.TabStop = false;
            // 
            // btnhip
            // 
            this.btnhip.BackColor = System.Drawing.Color.Gold;
            this.btnhip.Location = new System.Drawing.Point(37, 129);
            this.btnhip.Name = "btnhip";
            this.btnhip.Size = new System.Drawing.Size(118, 32);
            this.btnhip.TabIndex = 5;
            this.btnhip.Text = "HIP POP";
            this.btnhip.UseVisualStyleBackColor = false;
            this.btnhip.Click += new System.EventHandler(this.btnhip_Click);
            // 
            // lblanswer3
            // 
            this.lblanswer3.BackColor = System.Drawing.Color.Red;
            this.lblanswer3.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblanswer3.Location = new System.Drawing.Point(3, 209);
            this.lblanswer3.Name = "lblanswer3";
            this.lblanswer3.Size = new System.Drawing.Size(167, 46);
            this.lblanswer3.TabIndex = 30;
            // 
            // btnrnb
            // 
            this.btnrnb.BackColor = System.Drawing.Color.Gold;
            this.btnrnb.Font = new System.Drawing.Font("Microsoft JhengHei", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnrnb.Location = new System.Drawing.Point(37, 209);
            this.btnrnb.Name = "btnrnb";
            this.btnrnb.Size = new System.Drawing.Size(118, 34);
            this.btnrnb.TabIndex = 3;
            this.btnrnb.Text = "RNB";
            this.btnrnb.UseVisualStyleBackColor = false;
            this.btnrnb.Click += new System.EventHandler(this.btnrnb_Click);
            // 
            // btnhouse
            // 
            this.btnhouse.BackColor = System.Drawing.Color.Gold;
            this.btnhouse.Location = new System.Drawing.Point(37, 167);
            this.btnhouse.Name = "btnhouse";
            this.btnhouse.Size = new System.Drawing.Size(118, 31);
            this.btnhouse.TabIndex = 2;
            this.btnhouse.Text = "HOUSE";
            this.btnhouse.UseVisualStyleBackColor = false;
            this.btnhouse.Click += new System.EventHandler(this.btnhouse_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(14, 28);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(144, 81);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 1;
            this.pictureBox6.TabStop = false;
            // 
            // pnlbaby
            // 
            this.pnlbaby.BackColor = System.Drawing.Color.Gold;
            this.pnlbaby.Controls.Add(this.lblscore3);
            this.pnlbaby.Controls.Add(this.lblwrong2);
            this.pnlbaby.Controls.Add(this.pbwrong2);
            this.pnlbaby.Controls.Add(this.pbrightt2);
            this.pnlbaby.Controls.Add(this.lblincorrbaby);
            this.pnlbaby.Controls.Add(this.lblcorrbabby);
            this.pnlbaby.Controls.Add(this.label10);
            this.pnlbaby.Controls.Add(this.label9);
            this.pnlbaby.Controls.Add(this.label6);
            this.pnlbaby.Controls.Add(this.btnfuture);
            this.pnlbaby.Controls.Add(this.btndrake);
            this.pnlbaby.Controls.Add(this.btnjustin);
            this.pnlbaby.Location = new System.Drawing.Point(455, 96);
            this.pnlbaby.Name = "pnlbaby";
            this.pnlbaby.Size = new System.Drawing.Size(214, 287);
            this.pnlbaby.TabIndex = 45;
            this.pnlbaby.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlbaby_Paint);
            // 
            // lblscore3
            // 
            this.lblscore3.AutoSize = true;
            this.lblscore3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblscore3.Location = new System.Drawing.Point(136, 242);
            this.lblscore3.Name = "lblscore3";
            this.lblscore3.Size = new System.Drawing.Size(33, 13);
            this.lblscore3.TabIndex = 30;
            this.lblscore3.Text = "TIME";
            // 
            // lblwrong2
            // 
            this.lblwrong2.BackColor = System.Drawing.Color.Red;
            this.lblwrong2.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblwrong2.Location = new System.Drawing.Point(17, 173);
            this.lblwrong2.Name = "lblwrong2";
            this.lblwrong2.Size = new System.Drawing.Size(167, 46);
            this.lblwrong2.TabIndex = 29;
            this.lblwrong2.Text = "label13";
            // 
            // pbwrong2
            // 
            this.pbwrong2.Image = ((System.Drawing.Image)(resources.GetObject("pbwrong2.Image")));
            this.pbwrong2.Location = new System.Drawing.Point(56, 99);
            this.pbwrong2.Name = "pbwrong2";
            this.pbwrong2.Size = new System.Drawing.Size(100, 72);
            this.pbwrong2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbwrong2.TabIndex = 29;
            this.pbwrong2.TabStop = false;
            // 
            // pbrightt2
            // 
            this.pbrightt2.Image = ((System.Drawing.Image)(resources.GetObject("pbrightt2.Image")));
            this.pbrightt2.Location = new System.Drawing.Point(70, 120);
            this.pbrightt2.Name = "pbrightt2";
            this.pbrightt2.Size = new System.Drawing.Size(74, 76);
            this.pbrightt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbrightt2.TabIndex = 29;
            this.pbrightt2.TabStop = false;
            // 
            // lblincorrbaby
            // 
            this.lblincorrbaby.BackColor = System.Drawing.Color.Red;
            this.lblincorrbaby.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblincorrbaby.Location = new System.Drawing.Point(54, 79);
            this.lblincorrbaby.Name = "lblincorrbaby";
            this.lblincorrbaby.Size = new System.Drawing.Size(102, 20);
            this.lblincorrbaby.TabIndex = 29;
            this.lblincorrbaby.Text = "label13";
            // 
            // lblcorrbabby
            // 
            this.lblcorrbabby.BackColor = System.Drawing.Color.Lime;
            this.lblcorrbabby.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcorrbabby.Location = new System.Drawing.Point(67, 99);
            this.lblcorrbabby.Name = "lblcorrbabby";
            this.lblcorrbabby.Size = new System.Drawing.Size(84, 20);
            this.lblcorrbabby.TabIndex = 29;
            this.lblcorrbabby.Text = "label13";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Gold;
            this.label10.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(48, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 17);
            this.label10.TabIndex = 20;
            this.label10.Text = "BABY BABY ";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(51, 4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(105, 17);
            this.label9.TabIndex = 20;
            this.label9.Text = "WHO SINGS?";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label6.Location = new System.Drawing.Point(162, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(33, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "TIME";
            // 
            // btnfuture
            // 
            this.btnfuture.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnfuture.Location = new System.Drawing.Point(36, 202);
            this.btnfuture.Name = "btnfuture";
            this.btnfuture.Size = new System.Drawing.Size(133, 32);
            this.btnfuture.TabIndex = 6;
            this.btnfuture.Text = "Future";
            this.btnfuture.UseVisualStyleBackColor = false;
            this.btnfuture.Click += new System.EventHandler(this.btnfuture_Click);
            // 
            // btndrake
            // 
            this.btndrake.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btndrake.Location = new System.Drawing.Point(36, 136);
            this.btndrake.Name = "btndrake";
            this.btndrake.Size = new System.Drawing.Size(133, 37);
            this.btndrake.TabIndex = 7;
            this.btndrake.Text = "Drake";
            this.btndrake.UseVisualStyleBackColor = false;
            this.btndrake.Click += new System.EventHandler(this.btndrake_Click);
            // 
            // btnjustin
            // 
            this.btnjustin.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnjustin.Location = new System.Drawing.Point(36, 82);
            this.btnjustin.Name = "btnjustin";
            this.btnjustin.Size = new System.Drawing.Size(133, 37);
            this.btnjustin.TabIndex = 8;
            this.btnjustin.Text = "Justin bieber";
            this.btnjustin.UseVisualStyleBackColor = false;
            this.btnjustin.Click += new System.EventHandler(this.btnjustin_Click);
            // 
            // pnlcarly
            // 
            this.pnlcarly.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.pnlcarly.Controls.Add(this.lblscore2);
            this.pnlcarly.Controls.Add(this.lblanswers1);
            this.pnlcarly.Controls.Add(this.pbwrong1);
            this.pnlcarly.Controls.Add(this.pbright);
            this.pnlcarly.Controls.Add(this.lblincorrcarly);
            this.pnlcarly.Controls.Add(this.label8);
            this.pnlcarly.Controls.Add(this.lblcorrectcarly);
            this.pnlcarly.Controls.Add(this.label7);
            this.pnlcarly.Controls.Add(this.label5);
            this.pnlcarly.Controls.Add(this.btntaylor);
            this.pnlcarly.Controls.Add(this.btnladygag);
            this.pnlcarly.Controls.Add(this.btncarly);
            this.pnlcarly.Location = new System.Drawing.Point(237, 96);
            this.pnlcarly.Name = "pnlcarly";
            this.pnlcarly.Size = new System.Drawing.Size(212, 287);
            this.pnlcarly.TabIndex = 44;
            this.pnlcarly.Paint += new System.Windows.Forms.PaintEventHandler(this.pnlcarly_Paint);
            // 
            // lblscore2
            // 
            this.lblscore2.AutoSize = true;
            this.lblscore2.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblscore2.Location = new System.Drawing.Point(161, 235);
            this.lblscore2.Name = "lblscore2";
            this.lblscore2.Size = new System.Drawing.Size(33, 13);
            this.lblscore2.TabIndex = 29;
            this.lblscore2.Text = "TIME";
            // 
            // lblanswers1
            // 
            this.lblanswers1.BackColor = System.Drawing.Color.Red;
            this.lblanswers1.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblanswers1.Location = new System.Drawing.Point(16, 177);
            this.lblanswers1.Name = "lblanswers1";
            this.lblanswers1.Size = new System.Drawing.Size(167, 46);
            this.lblanswers1.TabIndex = 28;
            this.lblanswers1.Text = "label13";
            // 
            // pbwrong1
            // 
            this.pbwrong1.Image = ((System.Drawing.Image)(resources.GetObject("pbwrong1.Image")));
            this.pbwrong1.Location = new System.Drawing.Point(42, 102);
            this.pbwrong1.Name = "pbwrong1";
            this.pbwrong1.Size = new System.Drawing.Size(100, 72);
            this.pbwrong1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbwrong1.TabIndex = 28;
            this.pbwrong1.TabStop = false;
            // 
            // pbright
            // 
            this.pbright.Image = ((System.Drawing.Image)(resources.GetObject("pbright.Image")));
            this.pbright.Location = new System.Drawing.Point(53, 115);
            this.pbright.Name = "pbright";
            this.pbright.Size = new System.Drawing.Size(74, 76);
            this.pbright.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbright.TabIndex = 28;
            this.pbright.TabStop = false;
            // 
            // lblincorrcarly
            // 
            this.lblincorrcarly.BackColor = System.Drawing.Color.Red;
            this.lblincorrcarly.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblincorrcarly.Location = new System.Drawing.Point(42, 79);
            this.lblincorrcarly.Name = "lblincorrcarly";
            this.lblincorrcarly.Size = new System.Drawing.Size(100, 20);
            this.lblincorrcarly.TabIndex = 24;
            this.lblincorrcarly.Text = "label13";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Gold;
            this.label8.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Red;
            this.label8.Location = new System.Drawing.Point(16, 33);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(153, 17);
            this.label8.TabIndex = 19;
            this.label8.Text = "LAST FRIDAY NIGHT";
            // 
            // lblcorrectcarly
            // 
            this.lblcorrectcarly.BackColor = System.Drawing.Color.Lime;
            this.lblcorrectcarly.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcorrectcarly.Location = new System.Drawing.Point(57, 99);
            this.lblcorrectcarly.Name = "lblcorrectcarly";
            this.lblcorrectcarly.Size = new System.Drawing.Size(84, 20);
            this.lblcorrectcarly.TabIndex = 23;
            this.lblcorrectcarly.Text = "label13";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Gold;
            this.label7.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(39, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(95, 17);
            this.label7.TabIndex = 18;
            this.label7.Text = "WHO SINGS?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Gold;
            this.label5.Location = new System.Drawing.Point(161, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(33, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "TIME";
            // 
            // btntaylor
            // 
            this.btntaylor.BackColor = System.Drawing.Color.Gold;
            this.btntaylor.Location = new System.Drawing.Point(42, 147);
            this.btntaylor.Name = "btntaylor";
            this.btntaylor.Size = new System.Drawing.Size(115, 34);
            this.btntaylor.TabIndex = 17;
            this.btntaylor.Text = "Taylor Swift ";
            this.btntaylor.UseVisualStyleBackColor = false;
            this.btntaylor.Click += new System.EventHandler(this.btntaylor_Click);
            // 
            // btnladygag
            // 
            this.btnladygag.BackColor = System.Drawing.Color.Gold;
            this.btnladygag.Location = new System.Drawing.Point(42, 82);
            this.btnladygag.Name = "btnladygag";
            this.btnladygag.Size = new System.Drawing.Size(112, 34);
            this.btnladygag.TabIndex = 16;
            this.btnladygag.Text = "Lady Gaga";
            this.btnladygag.UseVisualStyleBackColor = false;
            this.btnladygag.Click += new System.EventHandler(this.btnladygag_Click);
            // 
            // btncarly
            // 
            this.btncarly.BackColor = System.Drawing.Color.Gold;
            this.btncarly.Location = new System.Drawing.Point(42, 216);
            this.btncarly.Name = "btncarly";
            this.btncarly.Size = new System.Drawing.Size(109, 33);
            this.btncarly.TabIndex = 15;
            this.btncarly.Text = "Carly Rae Japsen";
            this.btncarly.UseVisualStyleBackColor = false;
            this.btncarly.Click += new System.EventHandler(this.btncarly_Click);
            // 
            // pnldrake
            // 
            this.pnldrake.BackColor = System.Drawing.Color.Gold;
            this.pnldrake.Controls.Add(this.lblscore1);
            this.pnldrake.Controls.Add(this.pbwrong);
            this.pnldrake.Controls.Add(this.Lblanswer);
            this.pnldrake.Controls.Add(this.pbcorrect);
            this.pnldrake.Controls.Add(this.lblincorrectdrake);
            this.pnldrake.Controls.Add(this.lblcorrectdrake);
            this.pnldrake.Controls.Add(this.label11);
            this.pnldrake.Controls.Add(this.btnelectrodrake);
            this.pnldrake.Controls.Add(this.label3);
            this.pnldrake.Controls.Add(this.btntrapdrake);
            this.pnldrake.Controls.Add(this.btnhipop);
            this.pnldrake.Controls.Add(this.pictureBox4);
            this.pnldrake.Location = new System.Drawing.Point(16, 96);
            this.pnldrake.Name = "pnldrake";
            this.pnldrake.Size = new System.Drawing.Size(215, 291);
            this.pnldrake.TabIndex = 43;
            this.pnldrake.Paint += new System.Windows.Forms.PaintEventHandler(this.pnldrake_Paint);
            // 
            // lblscore1
            // 
            this.lblscore1.AutoSize = true;
            this.lblscore1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.lblscore1.Location = new System.Drawing.Point(165, 217);
            this.lblscore1.Name = "lblscore1";
            this.lblscore1.Size = new System.Drawing.Size(33, 13);
            this.lblscore1.TabIndex = 28;
            this.lblscore1.Text = "TIME";
            // 
            // pbwrong
            // 
            this.pbwrong.Image = ((System.Drawing.Image)(resources.GetObject("pbwrong.Image")));
            this.pbwrong.Location = new System.Drawing.Point(43, 177);
            this.pbwrong.Name = "pbwrong";
            this.pbwrong.Size = new System.Drawing.Size(100, 66);
            this.pbwrong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbwrong.TabIndex = 27;
            this.pbwrong.TabStop = false;
            // 
            // Lblanswer
            // 
            this.Lblanswer.BackColor = System.Drawing.Color.Red;
            this.Lblanswer.Font = new System.Drawing.Font("Agency FB", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblanswer.Location = new System.Drawing.Point(11, 239);
            this.Lblanswer.Name = "Lblanswer";
            this.Lblanswer.Size = new System.Drawing.Size(167, 46);
            this.Lblanswer.TabIndex = 23;
            this.Lblanswer.Text = "label13";
            // 
            // pbcorrect
            // 
            this.pbcorrect.Image = ((System.Drawing.Image)(resources.GetObject("pbcorrect.Image")));
            this.pbcorrect.Location = new System.Drawing.Point(48, 151);
            this.pbcorrect.Name = "pbcorrect";
            this.pbcorrect.Size = new System.Drawing.Size(74, 76);
            this.pbcorrect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbcorrect.TabIndex = 26;
            this.pbcorrect.TabStop = false;
            // 
            // lblincorrectdrake
            // 
            this.lblincorrectdrake.BackColor = System.Drawing.Color.Red;
            this.lblincorrectdrake.Font = new System.Drawing.Font("Ravie", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblincorrectdrake.Location = new System.Drawing.Point(25, 151);
            this.lblincorrectdrake.Name = "lblincorrectdrake";
            this.lblincorrectdrake.Size = new System.Drawing.Size(138, 35);
            this.lblincorrectdrake.TabIndex = 22;
            this.lblincorrectdrake.Text = "INCORRECT";
            // 
            // lblcorrectdrake
            // 
            this.lblcorrectdrake.BackColor = System.Drawing.Color.Lime;
            this.lblcorrectdrake.Font = new System.Drawing.Font("Ravie", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcorrectdrake.Location = new System.Drawing.Point(28, 126);
            this.lblcorrectdrake.Name = "lblcorrectdrake";
            this.lblcorrectdrake.Size = new System.Drawing.Size(120, 26);
            this.lblcorrectdrake.TabIndex = 0;
            this.lblcorrectdrake.Text = "label13";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Gold;
            this.label11.Font = new System.Drawing.Font("Ravie", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Red;
            this.label11.Location = new System.Drawing.Point(40, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(108, 17);
            this.label11.TabIndex = 20;
            this.label11.Text = "WHICH GENRE";
            // 
            // btnelectrodrake
            // 
            this.btnelectrodrake.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnelectrodrake.Location = new System.Drawing.Point(14, 201);
            this.btnelectrodrake.Name = "btnelectrodrake";
            this.btnelectrodrake.Size = new System.Drawing.Size(75, 29);
            this.btnelectrodrake.TabIndex = 12;
            this.btnelectrodrake.Text = "ElECTRO";
            this.btnelectrodrake.UseVisualStyleBackColor = false;
            this.btnelectrodrake.Click += new System.EventHandler(this.btnelectrodrake_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label3.Location = new System.Drawing.Point(179, 19);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "TIME";
            // 
            // btntrapdrake
            // 
            this.btntrapdrake.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btntrapdrake.Location = new System.Drawing.Point(14, 166);
            this.btntrapdrake.Name = "btntrapdrake";
            this.btntrapdrake.Size = new System.Drawing.Size(75, 29);
            this.btntrapdrake.TabIndex = 13;
            this.btntrapdrake.Text = "TRAP";
            this.btntrapdrake.UseVisualStyleBackColor = false;
            this.btntrapdrake.Click += new System.EventHandler(this.btntrapdrake_Click);
            // 
            // btnhipop
            // 
            this.btnhipop.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnhipop.Location = new System.Drawing.Point(14, 135);
            this.btnhipop.Name = "btnhipop";
            this.btnhipop.Size = new System.Drawing.Size(75, 28);
            this.btnhipop.TabIndex = 14;
            this.btnhipop.Text = "HIP POP";
            this.btnhipop.UseVisualStyleBackColor = false;
            this.btnhipop.Click += new System.EventHandler(this.btnhipop_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(14, 37);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(149, 86);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            // 
            // Lblscoreplayer1
            // 
            this.Lblscoreplayer1.AutoSize = true;
            this.Lblscoreplayer1.BackColor = System.Drawing.Color.Gold;
            this.Lblscoreplayer1.Font = new System.Drawing.Font("Ravie", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lblscoreplayer1.ForeColor = System.Drawing.Color.Red;
            this.Lblscoreplayer1.Location = new System.Drawing.Point(685, 432);
            this.Lblscoreplayer1.Name = "Lblscoreplayer1";
            this.Lblscoreplayer1.Size = new System.Drawing.Size(180, 19);
            this.Lblscoreplayer1.TabIndex = 52;
            this.Lblscoreplayer1.Text = "LAST FRIDAY NIGHT";
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.BackColor = System.Drawing.Color.Gold;
            this.lblTime.Font = new System.Drawing.Font("Ravie", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Location = new System.Drawing.Point(26, 57);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(66, 22);
            this.lblTime.TabIndex = 32;
            this.lblTime.Text = "TIME";
            // 
            // player22
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DeepPink;
            this.ClientSize = new System.Drawing.Size(900, 484);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.Lblscoreplayer1);
            this.Controls.Add(this.lblplayer2name);
            this.Controls.Add(this.lblname1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.btnfinish);
            this.Controls.Add(this.btnstart);
            this.Controls.Add(this.pnlealine);
            this.Controls.Add(this.pnlbaby);
            this.Controls.Add(this.pnlcarly);
            this.Controls.Add(this.pnldrake);
            this.Name = "player22";
            this.Text = "player22";
            this.Load += new System.EventHandler(this.player22_Load);
            this.pnlealine.ResumeLayout(false);
            this.pnlealine.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbcross)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbtick)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.pnlbaby.ResumeLayout(false);
            this.pnlbaby.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwrong2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbrightt2)).EndInit();
            this.pnlcarly.ResumeLayout(false);
            this.pnlcarly.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwrong1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbright)).EndInit();
            this.pnldrake.ResumeLayout(false);
            this.pnldrake.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbwrong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbcorrect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblplayer2name;
        private System.Windows.Forms.Label lblname1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Button btnfinish;
        private System.Windows.Forms.Button btnstart;
        private System.Windows.Forms.Panel pnlealine;
        private System.Windows.Forms.Label lblscore4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblincorrect3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pbcross;
        private System.Windows.Forms.Label lblcorrect3;
        private System.Windows.Forms.PictureBox pbtick;
        private System.Windows.Forms.Button btnhip;
        private System.Windows.Forms.Label lblanswer3;
        private System.Windows.Forms.Button btnrnb;
        private System.Windows.Forms.Button btnhouse;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel pnlbaby;
        private System.Windows.Forms.Label lblscore3;
        private System.Windows.Forms.Label lblwrong2;
        private System.Windows.Forms.PictureBox pbwrong2;
        private System.Windows.Forms.PictureBox pbrightt2;
        private System.Windows.Forms.Label lblincorrbaby;
        private System.Windows.Forms.Label lblcorrbabby;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnfuture;
        private System.Windows.Forms.Button btndrake;
        private System.Windows.Forms.Button btnjustin;
        private System.Windows.Forms.Panel pnlcarly;
        private System.Windows.Forms.Label lblscore2;
        private System.Windows.Forms.Label lblanswers1;
        private System.Windows.Forms.PictureBox pbwrong1;
        private System.Windows.Forms.PictureBox pbright;
        private System.Windows.Forms.Label lblincorrcarly;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblcorrectcarly;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btntaylor;
        private System.Windows.Forms.Button btnladygag;
        private System.Windows.Forms.Button btncarly;
        private System.Windows.Forms.Panel pnldrake;
        private System.Windows.Forms.Label lblscore1;
        private System.Windows.Forms.PictureBox pbwrong;
        private System.Windows.Forms.Label Lblanswer;
        private System.Windows.Forms.PictureBox pbcorrect;
        private System.Windows.Forms.Label lblincorrectdrake;
        private System.Windows.Forms.Label lblcorrectdrake;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button btnelectrodrake;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btntrapdrake;
        private System.Windows.Forms.Button btnhipop;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label Lblscoreplayer1;
        private System.Windows.Forms.Label lblTime;
    }
}